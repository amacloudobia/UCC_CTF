from flask import Flask, request
import requests
import re
from urllib.parse import urlparse

app = Flask(__name__)

# Simulated IAM role name and credentials
IAM_ROLE_NAME = "mock-role"
IAM_CREDENTIALS = {
    "AccessKeyId": "AKIAEXAMPLEACCESSKEY",
    "SecretAccessKey": "wJalrXUtnFEXAMPLESECRETKEY",
    "Token": "IQoJb3JpZ2luX2V4AMPLESESSIONTOKEN",
    "Expiration": "2024-12-31T23:59:59Z",
    "Flag": "FLAG{SSRF_IMDS_ACHIEVED}"
}

# Whitelisted domains (e.g., safe external domains)
WHITELISTED_DOMAINS = ['example.com']

def is_whitelisted(url):
    """
    Check if the provided URL belongs to the whitelisted domains.
    """
    try:
        parsed_url = urlparse(url)
        hostname = parsed_url.hostname
        if hostname in WHITELISTED_DOMAINS:
            return True
        return False
    except Exception:
        return False

@app.route('/')
def home():
    return '''
    <h1>SSRF Challenge - Room 3</h1>
    <p>Submit a URL to fetch its contents! (Only whitelisted domains are allowed)</p>
    <form action="/fetch" method="GET">
        <input type="text" name="url" placeholder="Enter URL" />
        <button type="submit">Fetch</button>
    </form>
    '''

@app.route('/fetch')
def fetch_url():
    url = request.args.get('url')
    if not url:
        return "Please provide a URL.", 400

    # Validate the URL against the whitelist
    if not is_whitelisted(url) and "169.254.169.254" not in url:
        return "Access denied! URL not in the whitelist.", 403

    try:
        # Simulate metadata service responses
        if url == "http://169.254.169.254/latest/meta-data/":
            return "iam/"
        elif url == "http://169.254.169.254/latest/meta-data/iam/":
            return "security-credentials/"
        elif url == "http://169.254.169.254/latest/meta-data/iam/security-credentials/":
            return f"{IAM_ROLE_NAME}"
        elif url == f"http://169.254.169.254/latest/meta-data/iam/security-credentials/{IAM_ROLE_NAME}":
            return {
                "Code": "Success",
                "LastUpdated": "2024-06-17T12:00:00Z",
                "Type": "AWS-HMAC",
                "AccessKeyId": IAM_CREDENTIALS['AccessKeyId'],
                "SecretAccessKey": IAM_CREDENTIALS['SecretAccessKey'],
                "Token": IAM_CREDENTIALS['Token'],
                "Expiration": IAM_CREDENTIALS['Expiration'],
                "Flag": IAM_CREDENTIALS['Flag']
            }
        else:
            # Default behavior for other URLs
            response = requests.get(url, timeout=3)
            return f"<pre>{response.text}</pre>"

    except Exception as e:
        return f"Error fetching the URL: {str(e)}"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)
