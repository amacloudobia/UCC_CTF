from flask import Flask, request
import requests
import re

app = Flask(__name__)

FLAG_FILE = 'flag.txt'

def is_blocked(url):
    """
    Function to block requests to localhost or 127.0.0.1 explicitly.
    """
    # Check for localhost and 127.0.0.1 using regex
    blocked_patterns = [r'localhost', r'127\.0\.0\.1']
    for pattern in blocked_patterns:
        if re.search(pattern, url, re.IGNORECASE):
            return True
    return False

@app.route('/')
def home():
    return '''
    <h1>SSRF Challenge - Room 2</h1>
    <p>Submit a URL to fetch its contents!</p>
    <form action="/fetch" method="GET">
        <input type="text" name="url" placeholder="Enter URL" />
        <button type="submit">Fetch</button>
    </form>
    '''

@app.route('/fetch')
def fetch_url():
    url = request.args.get('url')
    if not url:
        return "Please provide a URL.", 400

    # Check for blocked patterns
    if is_blocked(url):
        return "Access to localhost or 127.0.0.1 is blocked!", 403

    try:
        # Fetch the content of the provided URL
        response = requests.get(url, timeout=3)
        return f"<pre>{response.text}</pre>"
    except Exception as e:
        return f"Error fetching the URL: {str(e)}"

@app.route('/flag')
def flag():
    with open(FLAG_FILE, 'r') as file:
        return file.read()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)
